            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <?php 
    // Additional page-specific JavaScript if needed
    if (isset($additional_js)) {
        echo '<script>' . $additional_js . '</script>';
    }
    ?>
</body>
</html>